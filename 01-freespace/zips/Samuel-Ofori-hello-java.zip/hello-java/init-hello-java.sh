docker build -t helloworld:1.0.1 .
docker run helloworld:1.0.1

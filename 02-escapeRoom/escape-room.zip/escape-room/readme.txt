Welcome to the Bash Escape Room!
In the following excercise you are requested to move from room to room, starting with `room1`.

Most of the time the mission in order to get out of a room should be clear, but then again...

Good Luck!

Andrey & the deveLeap team 

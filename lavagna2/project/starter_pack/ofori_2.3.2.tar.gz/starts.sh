#!/bin/bash
docker-compose -f docker-compose-aws-instance.yml up 
